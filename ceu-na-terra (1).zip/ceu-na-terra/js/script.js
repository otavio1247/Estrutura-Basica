(function(){
"use strict";
const $=(s,r)=> (r||document).querySelector(s);
const $$=(s,r)=> Array.from((r||document).querySelectorAll(s));
const reduceMotion=matchMedia("(prefers-reduced-motion: reduce)").matches;
function rng(a){return function(){a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}}
const clamp=(v,a,b)=>Math.min(b,Math.max(a,v));
const fmt=(n,d)=>n.toLocaleString("pt-BR",{maximumFractionDigits:d||0,minimumFractionDigits:d||0});

/* ================= Tema e abas de páginas ================= */
(function chrome(){
  const root=document.documentElement, tb=$("#themeBtn");
  tb.addEventListener("click",()=>{
    const cur=root.getAttribute("data-theme")||(matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light");
    const next=cur==="dark"?"light":"dark";
    root.setAttribute("data-theme",next);
    try{localStorage.setItem("ceu-tema",next);}catch(e){}
  });
  const nav=$(".page-tabs"), cur=$(".page-tabs a[aria-current]");
  if(cur) nav.scrollLeft=cur.offsetLeft-(nav.clientWidth-cur.offsetWidth)/2;
})();

/* ================= Hero: órbitas ================= */
(function hero(){
  if(!document.querySelector("#orbit")) return;
  const cv=$("#orbit"), ctx=cv.getContext("2d");
  let W=0,H=0,t=0,running=true,raf=0;
  const r=rng(7);
  const stars=Array.from({length:90},()=>({x:r(),y:r(),s:r()*1.4+.3,a:r()*.6+.2}));
  const land=[];
  const noise=(a,b)=>Math.sin(b*2+1.3)*Math.cos(a*3-.4)+.6*Math.sin(b*5+a*2)+.5*Math.cos(b*3-a*4+2);
  for(let la=-80;la<=80;la+=4){
    const step=4/Math.max(Math.cos(la*Math.PI/180),.25);
    for(let lo=0;lo<360;lo+=step){const a=la*Math.PI/180,b=lo*Math.PI/180; if(noise(a,b)>.5) land.push([a,b]);}
  }
  const tilt=.42, ct=Math.cos(tilt), st=Math.sin(tilt);
  const orbits=[
    {r:1.5,inc:1.0,node:.4,speed:.55,sats:3,col:"#ffc233"},
    {r:1.85,inc:.45,node:2.2,speed:-.38,sats:3,col:"#76d6ff"},
    {r:2.2,inc:1.35,node:4.1,speed:.27,sats:3,col:"#ff9b7a"}
  ];
  function orbitPoint(o,th){
    let x=o.r*Math.cos(th), y=o.r*Math.sin(th)*Math.cos(o.inc), z=o.r*Math.sin(th)*Math.sin(o.inc);
    const cn=Math.cos(o.node), sn=Math.sin(o.node);
    const x2=x*cn+z*sn, z2=-x*sn+z*cn;
    const y3=y*ct-z2*st, z3=y*st+z2*ct;
    return {x:x2,y:y3,z:z3};
  }
  const g0={x:-.42,y:-.12,z:0}; g0.z=Math.sqrt(1-g0.x*g0.x-g0.y*g0.y);
  function size(){
    const b=cv.getBoundingClientRect(), d=Math.min(devicePixelRatio||1,2);
    W=b.width;H=b.height;cv.width=Math.round(W*d);cv.height=Math.round(H*d);ctx.setTransform(d,0,0,d,0,0);
    if(!running||reduceMotion) draw();
  }
  function draw(){
    ctx.clearRect(0,0,W,H);
    const cx=W/2, cy=H/2-8, R=Math.min(W,H)*.24;
    const P=p=>({x:cx+p.x*R,y:cy-p.y*R,z:p.z});
    stars.forEach(s=>{ctx.fillStyle="rgba(255,255,255,"+s.a+")";ctx.fillRect(s.x*W,s.y*H,s.s,s.s);});
    const sats=[];
    orbits.forEach((o,oi)=>{for(let i=0;i<o.sats;i++){const th=t*o.speed+i*(Math.PI*2/o.sats)+oi;sats.push({p:orbitPoint(o,th),o});}});
    function path(o,front){
      ctx.beginPath();let pen=false;
      for(let k=0;k<=96;k++){
        const q=orbitPoint(o,k/96*Math.PI*2), ok=front?q.z>=0:q.z<0, s=P(q);
        if(ok){pen?ctx.lineTo(s.x,s.y):ctx.moveTo(s.x,s.y);pen=true;}else pen=false;
      }
      ctx.stroke();
    }
    ctx.lineWidth=1;
    orbits.forEach(o=>{ctx.strokeStyle="rgba(180,210,255,.18)";path(o,false);});
    function drawSat(s,lit){
      const q=P(s.p);ctx.save();ctx.translate(q.x,q.y);
      if(lit){ctx.shadowColor=s.o.col;ctx.shadowBlur=14;}
      ctx.fillStyle=lit?s.o.col:"rgba(220,235,255,.8)";
      ctx.fillRect(-2.5,-2.5,5,5);
      ctx.fillStyle=lit?"rgba(255,255,255,.9)":"rgba(140,180,255,.7)";
      ctx.fillRect(-9,-1,5,2);ctx.fillRect(4,-1,5,2);
      ctx.restore();
    }
    sats.filter(s=>s.p.z<0).forEach(s=>drawSat(s,false));
    // atmosfera
    let gr=ctx.createRadialGradient(cx,cy,R*.95,cx,cy,R*1.35);
    gr.addColorStop(0,"rgba(90,160,255,.45)");gr.addColorStop(1,"rgba(90,160,255,0)");
    ctx.fillStyle=gr;ctx.beginPath();ctx.arc(cx,cy,R*1.35,0,7);ctx.fill();
    // esfera
    gr=ctx.createRadialGradient(cx-R*.4,cy-R*.4,R*.1,cx,cy,R);
    gr.addColorStop(0,"#2b6fc4");gr.addColorStop(.6,"#144080");gr.addColorStop(1,"#0a2147");
    ctx.fillStyle=gr;ctx.beginPath();ctx.arc(cx,cy,R,0,7);ctx.fill();
    // continentes em pontos
    const sp=t*.12;
    ctx.fillStyle="rgba(130,225,190,.9)";
    for(let i=0;i<land.length;i++){
      const a=land[i][0], b=land[i][1]+sp;
      const x=Math.cos(a)*Math.sin(b), y=Math.sin(a), z=Math.cos(a)*Math.cos(b);
      const y2=y*ct-z*st, z2=y*st+z*ct;
      if(z2>0){ctx.globalAlpha=.25+.75*z2;ctx.fillRect(cx+x*R-1,cy-y2*R-1,2.2,2.2);}
    }
    ctx.globalAlpha=1;
    ctx.strokeStyle="rgba(200,225,255,.35)";ctx.lineWidth=1.2;ctx.beginPath();ctx.arc(cx,cy,R,0,7);ctx.stroke();
    // ponto no solo e sinais
    const gp=P(g0);
    const vis=sats.map(s=>({s,d:s.p.x*g0.x+s.p.y*g0.y+s.p.z*g0.z})).filter(v=>v.d>1.02).sort((a,b)=>b.d-a.d).slice(0,4);
    vis.forEach((v,i)=>{
      const q=P(v.s.p);
      ctx.strokeStyle=v.s.o.col;ctx.globalAlpha=.55;ctx.lineWidth=1.3;
      ctx.beginPath();ctx.moveTo(gp.x,gp.y);ctx.lineTo(q.x,q.y);ctx.stroke();ctx.globalAlpha=1;
      const k=((t*.9+i*.27)%1);
      ctx.fillStyle="#fff";ctx.beginPath();ctx.arc(q.x+(gp.x-q.x)*k,q.y+(gp.y-q.y)*k,2.4,0,7);ctx.fill();
    });
    orbits.forEach(o=>{ctx.strokeStyle="rgba(180,210,255,.4)";ctx.lineWidth=1;path(o,true);});
    const litSet=new Set(vis.map(v=>v.s));
    sats.filter(s=>s.p.z>=0).forEach(s=>drawSat(s,litSet.has(s)));
    // marcador
    const pr=(Math.sin(t*3)+1)/2;
    ctx.strokeStyle="rgba(255,194,51,"+(.8-pr*.6)+")";ctx.lineWidth=1.6;ctx.beginPath();ctx.arc(gp.x,gp.y,5+pr*9,0,7);ctx.stroke();
    ctx.fillStyle="#ffc233";ctx.beginPath();ctx.arc(gp.x,gp.y,4.5,0,7);ctx.fill();
    ctx.fillStyle="#fff";ctx.font="700 14px 'Bricolage Grotesque',system-ui,sans-serif";ctx.textAlign="right";
    ctx.fillText("Você",gp.x-12,gp.y+5);
    ctx.textAlign="left";
  }
  let last=0;
  function loop(ts){
    if(!running) return;
    const dt=last?Math.min((ts-last)/1000,.05):0;last=ts;t+=dt;draw();raf=requestAnimationFrame(loop);
  }
  size();addEventListener("resize",size);
  if(reduceMotion){t=2.4;draw();return;}
  new IntersectionObserver(es=>{
    const v=es[0].isIntersecting;
    if(v&&!running){running=true;last=0;raf=requestAnimationFrame(loop);} else if(!v){running=false;cancelAnimationFrame(raf);}
  }).observe(cv);
  raf=requestAnimationFrame(loop);
})();

/* ================= GPS: trilateração ================= */
(function gps(){
  if(!document.querySelector("#gpsSvg")) return;
  const svg=$("#gpsSvg"), NS="http://www.w3.org/2000/svg";
  const sats=[{n:"A",x:110,y:62,c:"#f2a900"},{n:"B",x:325,y:40,c:"#13a89c"},{n:"C",x:545,y:80,c:"#e2502b"}];
  const KM_PX=75, C=299792;
  let user={x:300,y:322}, count=3;
  const groundY=x=>{const t=x/640;return(1-t)*(1-t)*330+2*(1-t)*t*250+t*t*330};
  function inter(a,b){
    const dx=b.x-a.x,dy=b.y-a.y,d=Math.hypot(dx,dy);
    if(!d||d>a.r+b.r||d<Math.abs(a.r-b.r)) return [];
    const l=(a.r*a.r-b.r*b.r+d*d)/(2*d),h=Math.sqrt(Math.max(a.r*a.r-l*l,0));
    const mx=a.x+l*dx/d,my=a.y+l*dy/d;
    return [{x:mx+h*dy/d,y:my-h*dx/d},{x:mx-h*dy/d,y:my+h*dx/d}];
  }
  const texts={
    1:["Qualquer ponto do círculo serve","Com um só satélite, você só sabe a que distância está dele. O aparelho poderia estar em qualquer lugar do círculo."],
    2:["Restam dois pontos possíveis","Dois círculos se cruzam em dois pontos. Um deles está no espaço ou fora da Terra, mas ainda falta um satélite para escolher com segurança."],
    3:["Só um ponto fica de acordo","Com três círculos, apenas um ponto pertence a todos. É a sua posição."]
  };
  function render(){
    const d=sats.map(s=>({...s,r:Math.hypot(s.x-user.x,s.y-user.y)}));
    let h='<rect class="gps-sky" width="640" height="420"/>';
    h+='<path class="gps-ground" d="M0 420V330Q320 250 640 330V420Z"/>';
    d.slice(0,count).forEach(s=>{
      h+='<circle cx="'+s.x+'" cy="'+s.y+'" r="'+s.r.toFixed(1)+'" fill="'+s.c+'" fill-opacity=".07" stroke="'+s.c+'" stroke-width="2.5" stroke-dasharray="7 7"/>';
      h+='<line x1="'+s.x+'" y1="'+s.y+'" x2="'+user.x+'" y2="'+user.y+'" stroke="'+s.c+'" stroke-width="1.5" opacity=".55"/>';
    });
    if(count===2){
      inter(d[0],d[1]).forEach(p=>{
        const real=Math.hypot(p.x-user.x,p.y-user.y)<2;
        h+='<circle cx="'+p.x.toFixed(1)+'" cy="'+p.y.toFixed(1)+'" r="9" fill="'+(real?"#fff":"none")+'" stroke="#fff" stroke-width="3"/><circle cx="'+p.x.toFixed(1)+'" cy="'+p.y.toFixed(1)+'" r="10" fill="none" stroke="#10233f" stroke-width="1.5"/>';
      });
    }
    d.forEach(s=>{
      const on=d.indexOf(s)<count;
      h+='<g transform="translate('+s.x+' '+s.y+')" opacity="'+(on?1:.35)+'"><rect x="-8" y="-8" width="16" height="16" rx="3" fill="'+s.c+'"/><rect x="-30" y="-3" width="18" height="6" fill="#4a86d6"/><rect x="12" y="-3" width="18" height="6" fill="#4a86d6"/><text class="svg-text" y="-16" text-anchor="middle" font-size="15">'+s.n+'</text></g>';
    });
    if(count===3||count===1){
      h+='<circle cx="'+user.x+'" cy="'+user.y+'" r="16" fill="#ffc233" fill-opacity=".25"/>';
    }
    h+='<circle cx="'+user.x+'" cy="'+user.y+'" r="8" fill="#ffc233" stroke="#fff" stroke-width="3"/>';
    h+='<text class="svg-text-on" x="'+user.x+'" y="'+(user.y+30)+'" text-anchor="middle" font-size="15">Você</text>';
    svg.innerHTML=h;
    $("#gpsTitle").textContent=texts[count][0];$("#gpsText").textContent=texts[count][1];
    $("#gpsList").innerHTML=d.slice(0,count).map(s=>{
      const km=s.r*KM_PX, ms=km/C*1000;
      return '<li><span class="dot" style="background:'+s.c+'"></span>Satélite '+s.n+': '+fmt(Math.round(km/10)*10)+' km, sinal em '+fmt(ms,1)+' ms</li>';
    }).join("");
  }
  function setUser(x,y){
    x=clamp(x,24,616);y=clamp(y,groundY(x)+20,396);user={x,y};render();
  }
  function toSvg(e){
    const pt=svg.createSVGPoint();pt.x=e.clientX;pt.y=e.clientY;
    return pt.matrixTransform(svg.getScreenCTM().inverse());
  }
  let drag=false;
  svg.addEventListener("pointerdown",e=>{drag=true;svg.setPointerCapture(e.pointerId);const p=toSvg(e);setUser(p.x,p.y);});
  svg.addEventListener("pointermove",e=>{if(drag){const p=toSvg(e);setUser(p.x,p.y);}});
  ["pointerup","pointercancel"].forEach(ev=>svg.addEventListener(ev,()=>{drag=false;}));
  svg.addEventListener("keydown",e=>{
    const m={ArrowLeft:[-12,0],ArrowRight:[12,0],ArrowUp:[0,-12],ArrowDown:[0,12]}[e.key];
    if(m){e.preventDefault();setUser(user.x+m[0],user.y+m[1]);}
  });
  $$(".sats-count .chip").forEach(b=>b.addEventListener("click",()=>{
    count=+b.dataset.n;$$(".sats-count .chip").forEach(x=>x.setAttribute("aria-pressed",String(x===b)));render();
  }));
  render();
})();

/* ================= Clima ================= */
(function weather(){
  if(!document.querySelector("#wxTabs")) return;
  const wrap=(inner,label)=>'<svg viewBox="0 0 400 300" preserveAspectRatio="xMidYMid slice" role="img" aria-label="'+label+'"><defs><filter id="wb3"><feGaussianBlur stdDeviation="3"/></filter><filter id="wb6"><feGaussianBlur stdDeviation="6"/></filter><filter id="wb10"><feGaussianBlur stdDeviation="10"/></filter></defs>'+inner+'</svg>';
  const scenes={
    nuvens(){
      const r=rng(3);let s='<rect width="400" height="300" fill="#1c4d8c"/><path d="M0 210C80 170 120 230 200 200S330 150 400 190V300H0Z" fill="#3b7a46"/><path d="M230 0C250 60 300 70 330 120S360 40 400 20V0Z" fill="#4a8a4f"/>';
      for(let i=0;i<24;i++) s+='<ellipse cx="'+(r()*400).toFixed(0)+'" cy="'+(r()*300).toFixed(0)+'" rx="'+(30+r()*60).toFixed(0)+'" ry="'+(12+r()*26).toFixed(0)+'" fill="#fff" opacity="'+(.45+r()*.4).toFixed(2)+'" filter="url(#wb10)"/>';
      return wrap(s,"Imagem ilustrativa de satélite com nuvens sobre terra e oceano");
    },
    oceanos(){
      const r=rng(9);
      let s='<defs><linearGradient id="sst" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#2b4fd1"/><stop offset=".4" stop-color="#2fb5c9"/><stop offset=".7" stop-color="#f2c744"/><stop offset="1" stop-color="#e2502b"/></linearGradient></defs><rect width="400" height="300" fill="url(#sst)"/>';
      const cols=["#e2502b","#2b4fd1","#f2c744","#2fb5c9"];
      for(let i=0;i<14;i++) s+='<circle cx="'+(r()*400).toFixed(0)+'" cy="'+(r()*300).toFixed(0)+'" r="'+(14+r()*30).toFixed(0)+'" fill="'+cols[Math.floor(r()*4)]+'" opacity=".7" filter="url(#wb10)"/>';
      s+='<path d="M0 0H120C90 60 130 90 90 150S40 230 70 300H0Z" fill="#32523a"/>';
      return wrap(s,"Mapa ilustrativo da temperatura da superfície do oceano, do azul frio ao vermelho quente");
    },
    secas(){
      const r=rng(5);let s='';
      const cw=50,ch=50;
      for(let y=0;y<6;y++)for(let x=0;x<8;x++){
        const dry=clamp((x/8)*.6+(1-y/6)*.25+(r()-.5)*.35,0,1);
        const c=[0,1,2].map(i=>Math.round([61,201,0][i]+([201,61,0][i]-[61,201,0][i])*0)).join(",");
        const g=[61,139,74],t=[201,165,102];
        const col="rgb("+g.map((v,i)=>Math.round(v+(t[i]-v)*dry)).join(",")+")";
        s+='<rect x="'+(x*cw)+'" y="'+(y*ch)+'" width="'+(cw-2)+'" height="'+(ch-2)+'" fill="'+col+'"/>';
      }
      s+='<path d="M0 150C100 130 160 190 400 120" stroke="#3b78c4" stroke-width="5" fill="none"/>';
      return wrap(s,"Mapa ilustrativo de lavouras com áreas verdes e áreas secas em tom de terra");
    },
    queimadas(){
      const r=rng(12);let s='<rect width="400" height="300" fill="#1f4a2a"/>';
      for(let i=0;i<70;i++) s+='<circle cx="'+(r()*400).toFixed(0)+'" cy="'+(r()*300).toFixed(0)+'" r="'+(6+r()*14).toFixed(0)+'" fill="'+(r()>.5?"#2a6035":"#173b20")+'"/>';
      for(let i=0;i<5;i++) s+='<ellipse cx="'+(150+i*60)+'" cy="'+(150-i*22)+'" rx="70" ry="22" fill="#cfd5db" opacity=".35" filter="url(#wb10)"/>';
      for(let i=0;i<22;i++){const x=(90+r()*120).toFixed(0),y=(150+r()*110).toFixed(0);s+='<circle cx="'+x+'" cy="'+y+'" r="7" fill="#ff7a1a" opacity=".5" filter="url(#wb3)"/><circle cx="'+x+'" cy="'+y+'" r="2.6" fill="#ffd34d"/>';}
      return wrap(s,"Imagem ilustrativa de floresta com focos de calor em laranja e fumaça cinza");
    },
    tempestades(){
      let s='<rect width="400" height="300" fill="#143768"/><circle cx="200" cy="150" r="150" fill="#2c5c9e" opacity=".5" filter="url(#wb10)"/>';
      for(let k=0;k<5;k++){
        let d="";
        for(let rad=14;rad<150;rad+=5){const a=k*Math.PI*2/5+rad*.045,x=200+Math.cos(a)*rad*1.25,y=150+Math.sin(a)*rad*.95;d+=(rad===14?"M":"L")+x.toFixed(1)+" "+y.toFixed(1);}
        s+='<path d="'+d+'" fill="none" stroke="#fff" stroke-width="22" stroke-linecap="round" opacity=".7" filter="url(#wb6)"/>';
      }
      s+='<circle cx="200" cy="150" r="13" fill="#0c2347"/>';
      return wrap(s,"Imagem ilustrativa de um furacão visto do espaço, com braços em espiral ao redor de um olho escuro");
    }
  };
  const data=[
    {k:"nuvens",t:"Nuvens",see:"Satélites geoestacionários fotografam o mesmo ponto a cada poucos minutos. Assim, dá para ver as nuvens crescendo, se movendo e virando chuva.",who:["Planejam plantio e colheita de acordo com a chuva prevista.","Alimentam modelos que calculam o clima dos próximos dias.","Emitem alertas de chuva forte e organizam a defesa civil."]},
    {k:"oceanos",t:"Oceanos",see:"Sensores infravermelhos medem a temperatura da superfície do mar. Águas mais quentes alimentam tempestades e alteram as chuvas em regiões inteiras.",who:["Acompanham fenômenos como o El Niño, que afetam safras.","Estudam correntes, ondas e mudanças no nível do mar.","Orientam navegação, pesca e proteção de áreas costeiras."]},
    {k:"secas",t:"Secas",see:"A cor da vegetação e a umidade do solo vistas do espaço mostram onde a água está faltando muito antes de a plantação murchar.",who:["Decidem quando irrigar e que cultura plantar.","Comparam décadas de imagens para entender tendências.","Preparam planos de abastecimento de água e apoio às famílias."]},
    {k:"queimadas",t:"Queimadas",see:"Sensores térmicos detectam pontos muito mais quentes que o entorno. Os chamados focos de calor aparecem no mapa em poucas horas.",who:["Se protegem e protegem pastagens e lavouras do fogo.","Medem a fumaça e o carbono emitido na atmosfera.","Enviam brigadas e fiscalizam áreas de risco."]},
    {k:"tempestades",t:"Tempestades",see:"Furacões, ciclones e frentes frias são acompanhados desde o nascimento. O formato e a velocidade das nuvens indicam a força do sistema.",who:["Evitam operar máquinas e armazenar grãos antes de temporais.","Melhoram a previsão de trajetória e intensidade.","Alertam a população e decidem evacuações a tempo."]}
  ];
  const tabs=$("#wxTabs"), panel=$("#wxPanel");
  data.forEach((d,i)=>{
    const b=document.createElement("button");b.className="chip";b.setAttribute("role","tab");b.id="wxt-"+d.k;b.textContent=d.t;
    b.addEventListener("click",()=>show(i));tabs.appendChild(b);
  });
  function show(i){
    const d=data[i];
    $$(".chip",tabs).forEach((b,j)=>{b.setAttribute("aria-selected",String(i===j));b.tabIndex=i===j?0:-1;});
    panel.setAttribute("aria-labelledby","wxt-"+d.k);
    panel.innerHTML='<div class="wx-img">'+scenes[d.k]()+'</div><div class="wx-body"><h3>Monitoramento de '+d.t.toLowerCase()+'</h3><p>'+d.see+'</p><div class="wx-who"><div><h4>Agricultores</h4><p>'+d.who[0]+'</p></div><div><h4>Cientistas</h4><p>'+d.who[1]+'</p></div><div><h4>Governos</h4><p>'+d.who[2]+'</p></div></div></div>';
  }
  tabs.addEventListener("keydown",e=>{
    const cur=$$(".chip",tabs).findIndex(b=>b.getAttribute("aria-selected")==="true");
    let n=cur;if(e.key==="ArrowRight")n=(cur+1)%data.length;else if(e.key==="ArrowLeft")n=(cur-1+data.length)%data.length;else return;
    e.preventDefault();show(n);$$(".chip",tabs)[n].focus();
  });
  show(0);
})();

/* ================= Comunicação ================= */
(function comm(){
  if(!document.querySelector("#destList")) return;
  const C=299792;
  const dests=[
    {n:"Satélite em órbita baixa",s:"Órbita baixa",km:[550]},
    {n:"Satélite de GPS",s:"GPS",km:[20200]},
    {n:"Satélite geoestacionário",s:"Geo",km:[35786]},
    {n:"Lua",s:"Lua",km:[384400]},
    {n:"Marte",s:"Marte",km:[54600000,401000000]}
  ];
  const fmtT=s=>{
    if(s<1){const ms=s*1000;return fmt(ms,ms<10?1:0)+" ms";}
    if(s<60) return fmt(s,s<10?2:1)+" s";
    return fmt(Math.round(s/60))+" min";
  };
  const rng2=(a,f)=>a.length>1?f(a[0])+" a "+f(a[1]):f(a[0]);
  const list=$("#destList"), pulse=$("#pulse");
  let anim=null;
  dests.forEach((d,i)=>{
    const b=document.createElement("button");b.className="chip";b.textContent=d.n;b.setAttribute("aria-pressed","false");
    b.addEventListener("click",()=>pick(i));list.appendChild(b);
  });
  function pick(i){
    const d=dests[i];
    $$(".chip",list).forEach((b,j)=>b.setAttribute("aria-pressed",String(i===j)));
    $("#destNode").textContent=d.s;
    $("#rDist").textContent=rng2(d.km,k=>k>=1e6?fmt(k/1e6)+" mi km":fmt(k)+" km").replace(/ mi km a /," a ");
    $("#rOne").textContent=rng2(d.km,k=>fmtT(k/C));
    $("#rRound").textContent=rng2(d.km,k=>fmtT(2*k/C));
    const tms=(d.km[d.km.length-1]/C)*1000, dur=900+380*Math.log10(1+tms);
    if(anim) anim.cancel();
    if(!reduceMotion){anim=pulse.animate([{left:"0%"},{left:"100%"}],{duration:dur,iterations:Infinity,easing:"linear"});}
    else pulse.style.left="50%";
  }
  pick(2);
})();

/* ================= Antes e depois ================= */
(function compare(){
  if(!document.querySelector("#cmp")) return;
  const r0=rng(21);
  function forest(r,withDefs){
    let s='<defs><filter id="cb"><feGaussianBlur stdDeviation="1.2"/></filter></defs><rect width="600" height="380" fill="#2c6a38"/>';
    const gs=["#1f5a2c","#2f7a3d","#256533","#3a8a47","#1a4d27"];
    for(let i=0;i<520;i++) s+='<circle cx="'+(r()*600).toFixed(0)+'" cy="'+(r()*380).toFixed(0)+'" r="'+(7+r()*13).toFixed(0)+'" fill="'+gs[Math.floor(r()*gs.length)]+'" opacity=".8"/>';
    return s;
  }
  const river='<path d="M-10 300C90 250 150 330 260 290S430 190 520 230 610 170 620 150" stroke="#2f78c4" stroke-width="13" fill="none" stroke-linecap="round"/><path d="M-10 300C90 250 150 330 260 290S430 190 520 230 610 170 620 150" stroke="#7fb8ee" stroke-width="4" fill="none" stroke-linecap="round" opacity=".7"/>';
  $("#cmpBefore").innerHTML=forest(rng(21))+river;
  // depois: espinha de peixe
  const r=rng(33);let s=forest(rng(21));
  const cleared=["#c9a870","#b99660","#d6bb86","#9db561","#a6a066"];
  s+='<path d="M300 -5V385" stroke="#8a6a3d" stroke-width="6"/>';
  for(let i=0;i<9;i++){
    const y=20+i*42, len=140+r()*170, side=i%2?1:-1;
    for(const sd of [-1,1]){
      const L=len*(sd===1?1:.8)+r()*30;
      const x0=sd===1?300:300-L;
      s+='<rect x="'+x0.toFixed(0)+'" y="'+y+'" width="'+L.toFixed(0)+'" height="'+(26+r()*10).toFixed(0)+'" fill="'+cleared[Math.floor(r()*cleared.length)]+'"/>';
      s+='<path d="M'+(sd===1?300:300-L)+' '+(y+13)+'H'+(sd===1?300+L:300)+'" stroke="#8a6a3d" stroke-width="2" opacity=".6"/>';
    }
  }
  s+=river;
  let hot='<g id="hot">';
  const rh=rng(44);
  for(let i=0;i<16;i++){const x=(60+rh()*480).toFixed(0),y=(20+rh()*340).toFixed(0);hot+='<circle cx="'+x+'" cy="'+y+'" r="9" fill="#ff7a1a" opacity=".55"/><circle cx="'+x+'" cy="'+y+'" r="3.2" fill="#ffe066" stroke="#e2502b" stroke-width="1"/>';}
  hot+='</g>';
  $("#cmpAfter").innerHTML=s+hot;
  const cmp=$("#cmp"), rg=$("#cmpRange");
  rg.addEventListener("input",()=>cmp.style.setProperty("--pos",rg.value+"%"));
  $("#hotToggle").addEventListener("change",e=>{$("#hot").style.opacity=e.target.checked?1:0;});
})();

/* ================= Agricultura ================= */
(function farm(){
  if(!document.querySelector("#field")) return;
  const COLS=16,ROWS=10,r=rng(11),cells=[];
  for(let y=0;y<ROWS;y++)for(let x=0;x<COLS;x++){
    const base=.5+.28*Math.sin(x*.45+1.2)+.2*Math.cos(y*.6+.4)+.14*Math.sin((x+y)*.33+2);
    const dry=Math.exp(-((x-11)**2/9+(y-3)**2/5));
    const m=clamp(base*.9-dry*.55+(r()-.5)*.12,0,1);
    const moist=8+34*m;
    const ndvi=.28+.62*clamp(.75*m+.25*clamp(base,0,1)+(r()-.5)*.08,0,1);
    const yld=36+(ndvi-.28)/.62*34;
    cells.push({x,y,moist,ndvi,yld});
  }
  const mix=(a,b,t)=>a.map((v,i)=>Math.round(v+(b[i]-v)*t));
  const ramp=(st,t)=>{t=clamp(t,0,1);const n=st.length-1,i=Math.min(n-1,Math.floor(t*n));return "rgb("+mix(st[i],st[i+1],t*n-i).join(",")+")";};
  const layers={
    ndvi:{f:c=>ramp([[178,58,48],[222,176,60],[133,178,70],[28,110,54]],(c.ndvi-.28)/.62),lo:"Vigor baixo",hi:"Vigor alto",g:"linear-gradient(90deg,rgb(178,58,48),rgb(222,176,60),rgb(133,178,70),rgb(28,110,54))"},
    moist:{f:c=>ramp([[196,160,110],[150,190,200],[40,110,190]],(c.moist-8)/34),lo:"Solo seco",hi:"Solo úmido",g:"linear-gradient(90deg,rgb(196,160,110),rgb(150,190,200),rgb(40,110,190))"},
    yield:{f:c=>ramp([[110,70,40],[214,163,60],[250,226,120]],(c.yld-36)/34),lo:"36 sacas/ha",hi:"70 sacas/ha",g:"linear-gradient(90deg,rgb(110,70,40),rgb(214,163,60),rgb(250,226,120))"}
  };
  const needs=c=>c.ndvi<.45||c.moist<18;
  const f=$("#field");let layer="ndvi",sel=cells.findIndex(c=>c.x===11&&c.y===3);
  const els=cells.map((c,i)=>{const d=document.createElement("div");d.dataset.i=i;f.appendChild(d);return d;});
  const pct=Math.round(cells.filter(needs).length/cells.length*100);
  function paint(){
    cells.forEach((c,i)=>{els[i].style.background=layers[layer].f(c);});
    const L=layers[layer];$("#legLo").textContent=L.lo;$("#legHi").textContent=L.hi;$("#legBar").style.background=L.g;
  }
  function info(){
    const c=cells[sel];
    els.forEach((e,i)=>e.classList.toggle("sel",i===sel));
    $("#cellName").textContent="Parcela "+String.fromCharCode(65+c.x)+(c.y+1);
    const q=c.ndvi<.45?"baixo":c.ndvi<.65?"médio":"alto";
    $("#cNdvi").textContent=fmt(c.ndvi,2)+" ("+q+")";
    $("#cMoist").textContent=fmt(c.moist,0)+"%";
    $("#cYield").textContent=fmt(c.yld,0)+" sacas/ha";
    $("#cAttn").textContent=pct+"%";
    let a;
    if(c.ndvi<.45&&c.moist<18) a="Prioridade alta: vigor baixo e solo seco. Vale conferir a irrigação desta parcela.";
    else if(c.ndvi<.45) a="Vigor baixo com umidade razoável. Pode haver praga, doença ou falta de nutrientes. Inspecione no campo.";
    else if(c.moist<18) a="O solo está secando. Programe a irrigação antes que o vigor das plantas caia.";
    else a="Parcela saudável. Mantenha o manejo atual.";
    $("#cAdvice").textContent=a;
  }
  f.addEventListener("pointermove",e=>{const t=e.target.closest("[data-i]");if(t&&+t.dataset.i!==sel){sel=+t.dataset.i;info();}});
  f.addEventListener("click",e=>{const t=e.target.closest("[data-i]");if(t){sel=+t.dataset.i;info();}});
  f.addEventListener("keydown",e=>{
    const d={ArrowLeft:-1,ArrowRight:1,ArrowUp:-COLS,ArrowDown:COLS}[e.key];
    if(d===undefined) return;e.preventDefault();
    const c=cells[sel];
    if((e.key==="ArrowLeft"&&c.x===0)||(e.key==="ArrowRight"&&c.x===COLS-1)) return;
    sel=clamp(sel+d,0,cells.length-1);info();
  });
  $$("#farmTabs .chip").forEach(b=>b.addEventListener("click",()=>{
    layer=b.dataset.layer;$$("#farmTabs .chip").forEach(x=>x.setAttribute("aria-pressed",String(x===b)));paint();
  }));
  paint();info();
})();

/* ================= Tecnologia ================= */
(function tech(){
  if(!document.querySelector("#techList")) return;
  const items=[
    {n:"Sensores de imagem CMOS",o:"Aperfeiçoados em laboratório de missões espaciais nos anos 1990",u:"Câmeras de celular, inspeção em fábricas, câmeras de segurança e cápsulas de endoscopia.",t:["Indústria","Segurança","Saúde"]},
    {n:"Software de processamento de imagens",o:"Criado para melhorar fotos de sondas e satélites",u:"Reconhecimento de padrões em linhas de produção, análise de mapas, monitoramento por câmeras e exames médicos.",t:["Indústria","Segurança","Ciência","Saúde"]},
    {n:"Espuma viscoelástica",o:"Desenvolvida nos anos 1960 em pesquisa financiada pela NASA para assentos de aeronaves",u:"Colchões, travesseiros, cadeiras de rodas e próteses mais confortáveis.",t:["Saúde","Indústria"]},
    {n:"Materiais leves e resistentes",o:"Necessários para reduzir o peso de foguetes e proteger satélites",u:"Aviação, bicicletas e equipamentos esportivos, capacetes e coletes de proteção.",t:["Indústria","Segurança"]},
    {n:"Purificação de água em circuito fechado",o:"Pensada para estações espaciais, onde cada gota é reaproveitada",u:"Sistemas portáteis de tratamento de água para comunidades remotas e situações de emergência.",t:["Saúde","Segurança"]},
    {n:"Sensores de baixo consumo e telemetria",o:"Feitos para operar por anos longe de qualquer manutenção",u:"Monitoramento de pontes, máquinas, florestas e rios, com dados enviados a distância.",t:["Indústria","Ciência","Segurança"]}
  ];
  const ul=$("#techList");
  ul.innerHTML=items.map((i,k)=>'<li data-t="'+i.t.join("|")+'"><div><h3>'+i.n+'</h3><small>'+i.t.join(", ")+'</small></div><div><p class="origin">'+i.o+'.</p><p>Hoje: '+i.u+'</p></div></li>').join("");
  $$("#techFilter .chip").forEach(b=>b.addEventListener("click",()=>{
    $$("#techFilter .chip").forEach(x=>x.setAttribute("aria-pressed",String(x===b)));
    $$("li",ul).forEach(li=>{li.hidden=!(b.dataset.f==="todas"||li.dataset.t.split("|").includes(b.dataset.f));});
  }));
})();

/* ================= Educação: peso em outros mundos ================= */
(function weight(){
  if(!document.querySelector("#bars")) return;
  const bodies=[["Lua",.165],["Marte",.38],["Vênus",.91],["Terra",1],["Júpiter",2.53]];
  const box=$("#bars"), inp=$("#mass");
  box.innerHTML=bodies.map((b,i)=>'<div class="bar-row"><span>'+b[0]+'</span><div class="b"><i id="bw'+i+'"></i></div><output id="bo'+i+'"></output></div>').join("");
  function up(){
    const m=clamp(parseFloat(String(inp.value).replace(",","."))||0,0,300);
    bodies.forEach((b,i)=>{$("#bw"+i).style.width=(b[1]/2.53*100)+"%";$("#bo"+i).textContent=fmt(m*b[1],1)+" kg";});
  }
  inp.addEventListener("input",up);up();
})();

/* ================= Dia a dia ================= */
(function day(){
  if(!document.querySelector("#dRange")) return;
  const apps=["GPS","Mapas","Previsão do tempo","Comunicação","Agricultura","Medicina","Análise de dados","Sensores"];
  const steps=[
    {h:"06:30",t:"O celular acorda você na hora certa",x:"A hora exata no seu aparelho vem de redes sincronizadas por relógios atômicos, muitos deles ajustados por sinais de satélite.",u:[0,3],sky:["#2b3f6e","#e0925a"],a:.12},
    {h:"08:00",t:"O aplicativo escolhe o caminho para o trabalho",x:"GPS dá a sua posição, mapas atualizados com imagens de satélite mostram as ruas e o trânsito é estimado a partir de milhares de aparelhos.",u:[0,1],sky:["#3b78c2","#f5c27a"],a:.28},
    {h:"10:00",t:"Sensores e dados em todo lugar",x:"Câmeras, sensores de movimento e bússolas do celular usam tecnologias refinadas pela exploração espacial. Programas de análise de dados dão sentido a tudo isso.",u:[6,7],sky:["#2f78d4","#8fcaf6"],a:.45},
    {h:"12:00",t:"O almoço chegou da lavoura",x:"Parte dos alimentos foi produzida com agricultura de precisão, que usa imagens de satélite e GPS para decidir onde irrigar e adubar.",u:[4,0],sky:["#2a73cc","#9fd3f7"],a:.55},
    {h:"14:30",t:"Guarda-chuva ou não?",x:"A previsão vem de satélites que acompanham nuvens, temperatura do mar e ventos, combinados com modelos de computador.",u:[2,6],sky:["#34649f","#9bb6d0"],a:.7},
    {h:"16:00",t:"Consulta com especialista à distância",x:"Telemedicina, imagens de exames processadas por algoritmos e conexão que chega a regiões afastadas ajudam a levar saúde a mais gente.",u:[5,3],sky:["#3a78c4","#f1c58a"],a:.85},
    {h:"18:30",t:"A comida do jantar vem por entrega",x:"Aplicativos acompanham o entregador em tempo real. As empresas planejam rotas com GPS para economizar tempo e combustível.",u:[0,1],sky:["#6a4a8a","#f08a5d"],a:1},
    {h:"21:00",t:"Videochamada e série pela internet",x:"A internet usa principalmente cabos submarinos, mas satélites completam a cobertura onde não há cabo e ajudam a sincronizar a rede.",u:[3,6],sky:["#14264a","#2b3f6e"],a:1.05},
    {h:"23:00",t:"O relógio de pulso monitora o sono",x:"Sensores miniaturizados, descendentes de tecnologias espaciais, registram batimentos e movimento, e enviam os dados para você acompanhar.",u:[7,5],sky:["#0a1630","#16264a"],a:1.15}
  ];
  const range=$("#dRange"), ul=$("#inuse"), sky=$("#sky"), orb=$("#orb");
  ul.innerHTML=apps.map(a=>'<li><span class="sw"></span>'+a+'</li>').join("");
  $("#dTicks").innerHTML=steps.map(s=>"<span>"+s.h.slice(0,2)+"h</span>").join("");
  function show(i){
    const s=steps[i];
    $("#dHour").textContent=s.h;$("#dTitle").textContent=s.t;$("#dText").textContent=s.x;
    range.setAttribute("aria-valuetext",s.h+", "+s.t);
    $$("li",ul).forEach((li,k)=>li.classList.toggle("on",s.u.includes(k)));
    sky.style.background="linear-gradient(180deg,"+s.sky[0]+","+s.sky[1]+")";
    const frac=i/(steps.length-1), night=i>=6;
    orb.style.left=(8+frac*84)+"%";
    orb.style.top=(100-Math.sin(frac*Math.PI)*75)+"px";
    orb.style.background=night?"#e8eef8":"#ffc233";
    orb.style.boxShadow=night?"0 0 24px 6px rgba(232,238,248,.4)":"0 0 34px 10px rgba(255,194,51,.55)";
  }
  range.addEventListener("input",()=>show(+range.value));
  show(0);
})();

})();
